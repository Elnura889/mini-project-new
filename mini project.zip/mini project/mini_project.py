from random import randint

num = randint(1, 100)
print("Угадайте число")
print("Случайное число находится между 1 до 100")
print("У вас есть неограниченное количество попыток")
print("Игра начинается...")

counter = 1
while True:
    guess = int(input("Попытка №" + str(counter) + ": "))
    if guess == num:
        print("Вы угадали!")
        print("Количество попыток: ", counter)
        break
    else:
        print("Вы не угадали, попробуйте еще!")
        if guess > num:
            print("Введеное вами число больше, чем надо")
        else:
            print("Введеное вами число ниже, чем еадо")
    counter += 1
