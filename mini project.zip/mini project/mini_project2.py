from random import randint

humans = 0
computers = 0

print("Камень")
print("Ножницы")
print("Бумага")

while True:
    computer = randint(1, 3)
    user = int(input("Сделайте свой выбор: "))
    if computer == 1:
        computer = "Камень"
    elif computer == 2:
        computer = "Ножницы"
    else:
        computer = "Бумага"
    if user == 1:
        user = "Камень"
    elif user == 2:
        user = "Ножницы"
    else:
        user = "Бумага"

    print("Ваш выбор: ", user)
    print("Выбор компьютера: ", computer)

    if (user == '' and computer == '') or (user == '' and computer == '') or (user == '' and computer == ''):
        print("Вы выиграли!")
        humans += 1
    elif user == computer:
        print("Ничья!")
    else:
        print("Компьютер выиграл!")
        computers += 1
    if humans == 3:
        print("Победа человества")
        break
    if computers == 3:
        print("Победа компьютера")
        break
